import React from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';
import JsonTable from 'react-json-table';

class DataToTable extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      posts: []
    };
  }

  componentDidMount() {
    axios.get(`https://api.github.com/users`)
      .then(res => {
        console.log(res.data);
        const posts = res.data;
        this.setState({ posts });
      });
  }

  render() {
    return (
      <JsonTable rows={this.state.posts}/>
    );
  }
}

ReactDOM.render(
  <DataToTable />,
  document.getElementById('container')
);
